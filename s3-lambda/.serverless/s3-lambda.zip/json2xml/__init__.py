# -*- coding: utf-8 -*-

"""Top-level package for json2xml."""

__author__ = """Vinit Kumar"""
__email__ = "mail@vinitkumar.me"
__version__ = "3.6.0"


# from .utils import readfromurl, readfromstring, readfromjson
